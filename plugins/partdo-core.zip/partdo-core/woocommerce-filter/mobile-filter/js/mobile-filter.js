(function ($) {
  "use strict";

	$(document).ready(function () {

		$('[data-toggle="offcanvas"]').on('click', function () {
			$('body').toggleClass('toggled');
		});  
	
	});

})(jQuery);
