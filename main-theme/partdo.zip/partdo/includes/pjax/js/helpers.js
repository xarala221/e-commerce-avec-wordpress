var partdoThemeModule = {};
/* global partdo_settings */

(function($) {

	partdoThemeModule.$window = $(window);

	partdoThemeModule.$document = $(document);

	partdoThemeModule.$body = $('body');


	
})(jQuery);